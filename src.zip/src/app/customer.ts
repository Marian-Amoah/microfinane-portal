export interface Customers {
  customerId: number;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  emailAddress: string;
  ghanaPostGPS: string;
  physicalAddress: string;
  customerPhoto: string;
  created: string;
  loans: Loans;
  investments: Investments;
  bankId: number;
  bankName: string;
  branch: string;
  bankAccountNumber: string;
  loanTypeId: number;
  loanType: string;
  interestRate: number;
  investmentTypesId: number;
  investmentType: string;
  referencesForLoansId: number;
  reference: string;
  paymentFrequenciesId: number;
  paymentFrequency: string;
}

  export interface loans {
      loanId: number;
      amount: number;
      dateOfLoan: string;
      expectedPayDate: string;
  }

export interface investments{
  investmentId: number
  amountInvested: number
  dateOfInvestment: String
  payableDate: String
}

  export interface Loans {
      numberOfLoans: number;
      loanTotal: number;
  }
  export interface Investments {
    numberOfInvestments: number;
    investmentTotal: number;
  }

  export interface RootObject {
      data: Customers[];
      Branches: Branch[];
  }

    export interface Branch {
        id: string;
        BranchName: string;
        BankId: string;
    }
  
 

    
  
  



 

  
  
  
  







