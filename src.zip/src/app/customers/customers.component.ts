import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import {  CustomerService } from '../services/customer.service';
import { Customers, RootObject } from '../customer';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import Swal from 'sweetalert2'

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.sass'],
  encapsulation: ViewEncapsulation.None,
})
export class CustomersComponent implements OnInit {
  SpreadCustomers: any;

  constructor(private formBuilder:FormBuilder, private customerService:CustomerService) {}
  
  //creating a form group for adding customer
  formData = new FormGroup({
      firstName: new FormControl( '' ),
      lastName:  new FormControl( '' ),
      dateOfBirth: new FormControl( '' ),
      emailAddress:  new FormControl( '' ),
      ghanaPostGPS: new FormControl( '' ),
      physicalAddress:  new FormControl( '' )
  });
  // end of form group

  

  // variable declarations
  isLoading: boolean = false;
  customers:Customers[] = [];
  editform!:FormGroup;
  reverse: boolean = false;
  key: string = 'customerId';
  p: number =1;



  ngOnInit(): void {
   //this is to get all customer data from the endpoint
   this.isLoading = true;
   this.customerService.customerApiGet().subscribe(
    { next:(data : RootObject) => {
      this.customers = data.data;
      let SpreadCustomers = [{...this.customers}]
    },
    error: (error)=> {
      console.log(error)
      alert("OOPS! Sorry, an error occured.");
    },
      complete: () => {this.isLoading = false} 
    }
    )
  
    //editing customer details
    this.editform = this.formBuilder.group({
      customerId:[''],
      firstName:[''],
      lastName:[''],
      dateOfBirth:[''],
      emailAddress:[''],
      ghanaPostGPS:[''],
      physicalAddress:[''],
  })
  }

//the sort function
  sort(key:string)
  {
    this.key= key;
    this.reverse = !this.reverse;
  }


  //function to create a new customer
  AddCustomer(){
    let payload = this.formData.value
    this.customerService.createCustomerApi(payload).subscribe((result:RootObject) =>{
      console.log(this.customers)
      this.customers.push(payload)
         console.log(payload)
})
}


//delete function
deleteCustomer(customerId:number,firstName:string,lastName:string){
  const swalWithBootstrapButtons = Swal.mixin({
    customClass: {
      confirmButton: 'btn btn-sm bg-primary',
      cancelButton: 'btn btn-sm bg-danger m-1'
    },
    buttonsStyling: false
  })
  swalWithBootstrapButtons.fire({
    title: "<h5 style='color:#07488d'>" + 'Are you sure you want to delete' + ' ' + firstName + ' ' + lastName + "</h5>",
    text: "You won't be able to revert this!",
    icon: 'warning',
    iconColor: '#d33',
    showCancelButton: true,
    confirmButtonText: 'Yes, delete it!', 
    cancelButtonText: 'No, cancel!',
    reverseButtons: true
  }).then((result) => {
    if (result.isConfirmed) {
      this.customerService.deleteCustomerApi(customerId).subscribe((result) => {
      } )
      swalWithBootstrapButtons.fire(
        'Deleted!',
        'Your file has been created successfully.',
        'success'
      ).then((endResult)=>{
        if(endResult.isConfirmed){
          window.location.reload();
        }
      })
    } 
  })
}


//function to load data onto the form
editCustomer(data:RootObject){
  this.editform.setValue(data)
}

//update function
UpdateCustomer(){
  this.customerService.updateCustomerApi(this.editform.value.customerId,this.editform.value).subscribe((result) =>{
})
Swal.fire(
  'Good job!',
  'customer record has been updated successfully!',
  'success'
).then((endResult)=>{
  if(endResult.isConfirmed){
    window.location.reload();
  }
})
error: (e) => {
  Swal.fire({
    icon: 'error',
    title: 'Oops...',
    text: 'Something went wrong!',
    footer: '<a href="">Why do I have this issue?</a>'
  })
}
}
}

