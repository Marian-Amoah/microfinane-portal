import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { RootObject } from '../customer'


@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private httpClient:HttpClient) { }

  url = 'https://coj12ojfk1.execute-api.eu-west-1.amazonaws.com/Prod/';

  // get customer details
  customerApiGet():Observable<RootObject>{
    return this.httpClient.get<RootObject>(this.url + 'customers?all=True')
  }

  // create a new customer
  createCustomerApi(Customerdata:any):Observable<RootObject>{
    return this.httpClient.post<RootObject>(this.url + 'customers', Customerdata)
  }

//delete customer record
  deleteCustomerApi(customerId:number){
    return this.httpClient.delete(`${this.url}` + 'customers' + '/' + `${customerId}`)
  }
  
//update customer record
  updateCustomerApi(customerId:number, data:RootObject):Observable<RootObject>{
    return this.httpClient.put<RootObject>(`${this.url}` + 'customers' + '/' + `${customerId}`, data)
  }

//get a single customer
getSingleCustomer(customerId:number):Observable<RootObject>{
  return this.httpClient.get<RootObject>(`${this.url}` + 'customers' + '/' + `${customerId}`)
}

//get bank account detail of a customer
getBankaccountDetail(customerId:number):Observable<RootObject>{
  return this.httpClient.get<RootObject>(`${this.url}` + 'bankAccountDetails' + '/' + `${customerId}`)
}

//get loan detail of a customer
getLoanDetail(customerId:number):Observable<RootObject>{
  return this.httpClient.get<RootObject>(`${this.url}` + 'customerloans' + '/' + `${customerId}`)
}

//get Investment detail of a customer
getInvestmentDetail(customerId:number):Observable<RootObject>{
  return this.httpClient.get<RootObject>(`${this.url}` + 'customerinvestments' + '/' + `${customerId}`)
}

//get loan types
getloanTypes():Observable<RootObject>{
  return this.httpClient.get<RootObject>(this.url + 'loanTypes')
}

//get investment types
getinvestmentTypes():Observable<RootObject>{
  return this.httpClient.get<RootObject>(this.url + 'investmentTypes')
}

//get payment frequency
getPaymentfrequency():Observable<RootObject>{
  return this.httpClient.get<RootObject>(this.url + 'paymentFrequencies')
}

//get loan reference
getLoanReference():Observable<RootObject>{
  return this.httpClient.get<RootObject>(this.url + 'referencesForLoans')
}

//create a new loan
createNewLoan(data):Observable<RootObject>{
  return this.httpClient.post<RootObject>(this.url + 'loans', data)
}

//create a new investment
createNewInvestment(data):Observable<RootObject>{
  return this.httpClient.post<RootObject>(this.url + 'investments', data)
}

//create a new account
createNewAccount(data:any){
  return this.httpClient.post(this.url + 'bankAccountDetails', data)
}

//get branches
getBranch():Observable<RootObject>{
  return this.httpClient.get<RootObject>("assets/db.json")
}

//get banks
getBanks():Observable<RootObject>{
  return this.httpClient.get<RootObject>(this.url + 'banks')
}

//get loans
getLoans():Observable<RootObject>{
  return this.httpClient.get<RootObject>(this.url + 'loans?all=True')
}

//get investments
getInvestments():Observable<RootObject>{
  return this.httpClient.get<RootObject>(this.url + 'investments?all=True')
}
}