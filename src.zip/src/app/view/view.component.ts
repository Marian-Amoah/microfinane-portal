import { Component, OnInit } from '@angular/core';
import { Customers, RootObject, Branch } from '../customer';
import {  CustomerService } from '../services/customer.service';
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import Swal from 'sweetalert2'

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.sass']
})
export class ViewComponent implements OnInit {
constructor(private ViewcustomerService:CustomerService, private route: ActivatedRoute,private formBuilder:FormBuilder) { }

// variable declarations
customers:Customers[] = [];
loans:Customers[] = [];
investments:Customers[];
LoanType:Customers[] = [];
InvestmentType:Customers[] = [];
LoanReference:Customers[];
PaymentFrequency:Customers[];
Bank:Customers[] = [];
BankDetails:Customers[] = [];
customerId: number;
branches: Branch[];
Singlecustomer: Customers[] = [];
selectedBranch: Branch[];


ngOnInit(): void {
  this.customerId=this.route.snapshot.params['customerId'];

     //this is to get a single customer data from the endpoint
     this.ViewcustomerService.getSingleCustomer(this.customerId).subscribe(
      { next:(data : RootObject) => {
        this.Singlecustomer = data.data;
      },
      error: (error)=> {
        console.log(error)
      }
      })

      
    //this is to get the bank account details of a customer from the endpoint
  this.ViewcustomerService.getBankaccountDetail(this.customerId).subscribe(
    { next:(data : RootObject) => {
      this.BankDetails = data.data;
    },
    error: (error)=> {
      console.log(error)
    }
    })

    //this is to get the loan details of a customer from the endpoint
  this.ViewcustomerService.getLoanDetail(this.customerId).subscribe(
    { next:(data : RootObject) => {
      this.loans = data.data;
    },
    error: (error)=> {
      console.log(error)
    }
    })

    //this is to get the investment details of a customer from the endpoint
  this.ViewcustomerService.getInvestmentDetail(this.customerId).subscribe(
      { next:(data : RootObject) => {
        this.investments = data.data;
      },
      error: (error)=> {
        console.log(error)
      }
      })

    //this is to get loantypes
  this.ViewcustomerService.getloanTypes().subscribe(
    { next:(data : RootObject) => {
      this.LoanType = data.data;
    },
    error: (error)=> {
      console.log(error)
    }
    })


    //this is to get investment types
  this.ViewcustomerService.getinvestmentTypes().subscribe(
    { next:(data : RootObject) => {
      this.InvestmentType = data.data;
    },
    error: (error)=> {
      console.log(error)
    }
    })

    //this is to get the payment Frequencies
    this.ViewcustomerService.getPaymentfrequency().subscribe(
      { next:(data : RootObject) => {
        this.PaymentFrequency = data.data;
      },
      error: (error)=> {
        console.log(error)
      }
      })


    //this is to get the loan reference
    this.ViewcustomerService.getLoanReference().subscribe(
      { next:(data : RootObject) => {
        this.LoanReference = data.data;
      },
      error: (error)=> {
        console.log(error)
      }
      })

      //this is to get all banks
      this.ViewcustomerService.getBanks().subscribe(
        { next:(data : RootObject) => {
          this.Bank = data.data;
        },
        error: (error)=> {
          console.log(error)
        }
        })

    //this is to get the bank branches
    this.ViewcustomerService.getBranch().subscribe(
      { next:(data : RootObject) => {
        this.branches= data.Branches;
      },
      error: (error)=> {
        console.log(error)
      }
      })
}



// creating a form group for adding a new loan
  LoanformData = new FormGroup({
    amount: new FormControl( '' ),
    customerId:  new FormControl(''),
    expectedPayDate: new FormControl( '' ),
    loanTypeId:  new FormControl( '' ),
    paymentFrequenciesId: new FormControl( '' ),
    referencesForLoansId:  new FormControl( '' ),
    amountInvested:new FormControl(''),
    payableDate: new FormControl(''),
    investmentTypesId: new FormControl('')
});

//formgroup for creating bank account
BankAccountForm = new FormGroup ({
  bankId: new FormControl(''),
  branch: new FormControl(''),
  bankAccountNumber: new FormControl('')
});


  //function to create a new loan for a customer
  AddNewLoan(){
    let payload = this.LoanformData.value
    payload['customerId'] = this.customerId
    payload['loanTypeId']=parseInt(this.LoanformData.get('loanTypeId')?.value)
    payload['referencesForLoansId']=parseInt(this.LoanformData.get('referencesForLoansId')?.value)
    payload['paymentFrequenciesId']=parseInt(this.LoanformData.get('paymentFrequenciesId')?.value)
    this.ViewcustomerService.createNewLoan(payload).subscribe((result) =>{
      console.log(result)
      console.log(payload)
    })
    Swal.fire(
      'successful!',
      'Loan has been created successfully',
      'success'
    ).then((endResult)=>{
      if(endResult.isConfirmed){
        window.location.reload();
      }
    })
    error: (e) => {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Something went wrong!',
        footer: '<a href="">Why do I have this issue?</a>'
      })
    }
}
  //function to create a new investment for a customer
  AddNewInvestment(){
    let payload = this.LoanformData.value
    console.log(this.customerId)
    payload['customerId'] = this.customerId
    payload['investmentTypesId']=parseInt(this.LoanformData.get('investmentTypesId')?.value)
    this.ViewcustomerService.createNewInvestment(payload).subscribe((result) =>{
      console.log(result)
      console.log(payload)
    })
    Swal.fire(
      'successful!',
      'Investment has been created successfully',
      'success'
    ).then((endResult)=>{
      if(endResult.isConfirmed){
        window.location.reload();
      }
    })
    error: (e) => {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Something went wrong!',
        footer: '<a href="">Why do I have this issue?</a>'
      })
    }
}
  //function to create a new bank account for a customer
  AddCustomer(){
    let payload = this.BankAccountForm.value
    console.log(this.customerId)
    payload['customerId'] = Number(this.customerId)
    payload['bankId']=parseInt(this.BankAccountForm.get('bankId')?.value)
    this.ViewcustomerService.createNewAccount(payload).subscribe((result) =>{
      this.BankDetails.push(payload)
      console.log(result)
      console.log(payload)
    })
}
  AddNewAccount(){
    let payload = this.BankAccountForm.value
    console.log(this.customerId)
    payload['customerId'] = this.customerId
    payload['bankId']=parseInt(this.BankAccountForm.get('bankId')?.value)
    this.ViewcustomerService.createNewAccount(payload).subscribe((result) =>{
      console.log(result)
      console.log(payload)
    })
    Swal.fire(
      'successful!',
      'Account has been created successfully',
      'success'
    ).then((endResult)=>{
      if(endResult.isConfirmed){
        window.location.reload();
      }
    })
    error: (e) => {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Something went wrong!',
        footer: '<a href="">Why do I have this issue?</a>'
      })
    }
}
//this displays list of branches when a bank is selected
onSelect(BankId :number){
  this.selectedBranch =  this.branches.filter(data =>
  data.BankId === this.BankAccountForm.get('bankId')?.value ) 
}
}
