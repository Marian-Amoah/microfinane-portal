import { Component, OnInit } from "@angular/core";
import { Customers, RootObject, Branch } from "src/app/interfaces/customer";
import { ActivatedRoute } from "@angular/router";
import { BreadcrumbService } from "src/app/services/misc/breadcrumb/breadcrumb.service";
import { LoansManagerService } from "src/app/services/LoansManager/loans-manager.service";
import {
  NgbTabChangeEvent,
  NgbModal,
  NgbModalRef,
  ModalDismissReasons,
  NgbActiveModal,
} from "@ng-bootstrap/ng-bootstrap";
import { FormGroup, FormControl } from "@angular/forms";
import { SweetalertService } from "src/app/services/sweetalert/sweetalert.service";
import Swal from "sweetalert2";

@Component({
  selector: "app-view-client-details",
  templateUrl: "./view-client-details.component.html",
  styleUrls: ["./view-client-details.component.css"],
})
export class ViewClientDetailsComponent implements OnInit {
  // customerId: number;
  currentJustify = "start";
  loans: Customers[] = [];
  investments: Customers[];
  BankDetails: Customers[] = [];
  Singlecustomer: Customers[] = [];
  closeResult: string;
  customers: Customers[] = [];
  InvestmentType: Customers[] = [];
  LoanReference: Customers[];
  PaymentFrequency: Customers[];
  Bank: Customers[] = [];
  LoanType: Customers[] = [];
  branches: Branch[];
  selectedBranch: Branch[];
  isConfirmed: boolean = true;
  isCustomerID: number;
  spinner: boolean = true;

  currentOrientation = "horizontal";
  public beforeChange($event: NgbTabChangeEvent) {
    if ($event.nextId === "tab-preventchange2") {
      $event.preventDefault();
    }
  }
  constructor(
    private route: ActivatedRoute,
    private crumb: BreadcrumbService,
    private loansManager: LoansManagerService,
    private modalService: NgbModal,
    private modalService2: NgbModal,
    private sweetAlert: SweetalertService
  ) {
    this.crumb.setCrumb([{ name: "View Details", link: "/view" }]);
  }

  //modal
  open(content) {
    this.modalService2.open(content, { windowClass: "dark-modal" });
  }
  //end of modal

  async ngOnInit() {
    this.isCustomerID = Number(this.route.snapshot.params["customerId"]);

    //this is to get a single customer data from the endpoint
    try {
      const { data, responseCode, responseMessage } = await this.loansManager
      .getSingleCustomer(this.isCustomerID)
      .toPromise();
      if (responseCode && responseCode.toString() === "200") {
        this.Singlecustomer = data;
      } else {
        this.sweetAlert.showErrorMessage("OOPS!", responseMessage);
      }
    } catch (error) {
      console.log(error);
      this.sweetAlert.showErrorMessage("OOPS!", 'Something went wrong');
    } finally {
      this.spinner= false;
    }
    // end of single customer



    
    //this is to get the bank account details of a customer from the endpoint
    try {
      this.spinner = true;
      const { data, responseCode, responseMessage } = await this.loansManager
        .getBankaccountDetail(this.isCustomerID)
        .toPromise();
      if (responseCode && responseCode.toString() === "200") {
        this.BankDetails = data;
      } else {
        this.sweetAlert.showErrorMessageView('No Account Record');
      }
    } 
    catch (error) {
      console.log(error);
      this.sweetAlert.showErrorMessage("OOPS!", 'Something went wrong');
    }
     finally {
      this.spinner = false;
    }
    // end of single bank account detail


    //this is to get the loan details of a customer from the endpoint
    try {
      const { data, responseCode, responseMessage } = await this.loansManager
        .getLoanDetail(this.isCustomerID)
        .toPromise();
      if (responseCode && responseCode.toString() === "200") {
        this.loans = data;
      }
      else {
        this.sweetAlert.showErrorMessageView('No Loan Record');
      }
    } catch (error) {
      console.log(error);
      this.sweetAlert.showErrorMessage("OOPS!", 'Something went wrong');
    } finally {
      this.spinner = false;
    }
    //end of loan detail


    //this is to get the investment details of a customer from the endpoint
    try {
      const { data, responseCode, responseMessage } = await this.loansManager
        .getInvestmentDetail(this.isCustomerID)
        .toPromise()
        .then();
      if (responseCode && responseCode.toString() === "200") {
        this.investments = data;
      }
      else {
        this.sweetAlert.showErrorMessageView('No Investment Record');
      }
    } catch (error) {
      console.log(error);
      this.sweetAlert.showErrorMessage("OOPS!", 'Something went wrong');
    } finally {
      this.spinner = false;
    }
    //end of investment detail



    //this is to get loantypes
    try {
      const { data, responseCode, responseMessage } = await this.loansManager
        .getloanTypes()
        .toPromise();
      if (responseCode && responseCode.toString() === "200") {
        this.LoanType = data;
      }
    } finally {
      this.spinner = false;
    }
    //end of loan types


    //this is to get investment types
    try {
      const { data, responseCode, responseMessage } = await this.loansManager
        .getinvestmentTypes()
        .toPromise();
      if (responseCode && responseCode.toString() === "200") {
        this.InvestmentType = data;
      }
      else {
        this.sweetAlert.showErrorMessage("OOPS!", responseMessage);
      }
    } catch (error) {
      console.log(error);
      this.sweetAlert.showErrorMessage("OOPS!", 'Something went wrong');
    } finally {
      this.spinner = false;
    }
    //end of investment type


    //this is to get the payment Frequencies
    try {
      const { data, responseCode, responseMessage } = await this.loansManager
        .getPaymentfrequency()
        .toPromise();
      if (responseCode && responseCode.toString() === "200") {
        this.PaymentFrequency = data;
      }
      else {
        this.sweetAlert.showErrorMessage("OOPS!", responseMessage);
      }
    } catch (error) {
      console.log(error);
      this.sweetAlert.showErrorMessage("OOPS!", 'Something went wrong');
    } finally {
      this.spinner = false;
    }
    //end of payment frequencies


    //this is to get the loan reference
    try {
      const { data, responseCode, responseMessage } = await this.loansManager
        .getLoanReference()
        .toPromise();
      if (responseCode && responseCode.toString() === "200") {
        this.LoanReference = data;
      }
      else {
        this.sweetAlert.showErrorMessage("OOPS!", responseMessage);
      }
    } catch (error) {
      console.log(error);
      this.sweetAlert.showErrorMessage("OOPS!", 'Something went wrong');
    } finally {
      this.spinner = false;
    }
    //end of loans refrence

    
    //this is to get all banks
    try {
      const { data, responseCode, responseMessage } = await this.loansManager
        .getBanks()
        .toPromise();
      if (responseCode && responseCode.toString() === "200") {
        this.Bank = data;
      }
    } finally {
      this.spinner = false;
    }
    //end of all banks


    //this is to get the bank branches
    this.loansManager.getBranch().subscribe({
      next: (data: RootObject) => {
        this.branches = data.Branches;
      },
      error: (error) => {
        console.log(error);
      },
    });
    //end of branches
  }

  // creating a form group for adding a new loan
  LoanformData = new FormGroup({
    amount: new FormControl(""),
    customerId: new FormControl(""),
    expectedPayDate: new FormControl(""),
    loanTypeId: new FormControl(""),
    paymentFrequenciesId: new FormControl(""),
    referencesForLoansId: new FormControl(""),
  });
  // end form group for adding a new loan


  // creating a form group for adding a new investment
  InvestmentformData = new FormGroup({
    amountInvested: new FormControl(""),
    customerId: new FormControl(""),
    investmentTypesId: new FormControl(""),
    payableDate: new FormControl(""),
  });
  // end of form group for adding a new investment



  //formgroup for creating bank account
  BankAccountForm = new FormGroup({
    bankId: new FormControl(""),
    branch: new FormControl(""),
    bankAccountNumber: new FormControl(""),
    customerId: new FormControl(""),
  });
  // end of form group for adding a new bank account



  //this displays list of branches when a bank is selected
  onSelect(BankId: number) {
    this.selectedBranch = this.branches.filter(
      (data) => data.BankId === this.BankAccountForm.get("bankId").value
    );
  }
  // end of select



  //function to create a new loan for a customer
  async AddNewLoan() {
    let payload = this.LoanformData.value;
    payload["customerId"] = this.isCustomerID;
    payload["loanTypeId"] = parseInt(this.LoanformData.get("loanTypeId").value);
    payload["referencesForLoansId"] = parseInt(
      this.LoanformData.get("referencesForLoansId").value
    );
    payload["paymentFrequenciesId"] = parseInt(
      this.LoanformData.get("paymentFrequenciesId").value
    );
    try {
      const { data, responseCode, responseMessage } = await this.loansManager
      .createNewLoan(payload)
      .toPromise();
      if (responseCode && responseCode.toString() === "200") {
        this.sweetAlert
          .showSuccessMessage(
            "Loan has been created successfully!",
            responseMessage
          )
          .then((data) => {
            if (this.isConfirmed) {
              this.loans;
            }
          });
      }
      else {
        this.sweetAlert.showErrorMessage("OOPS!", responseMessage);
       }
    } 
    catch (error) {
      this.sweetAlert.showErrorMessage(
        "OOPS!",
        "Sorry, an error occured. Try again later."
      );
    } finally {
      this.LoanformData.reset()
    }
  }
  // end of loan function



  //function to create a new investment for a customer
  async AddNewInvestment() {
    let payload = this.InvestmentformData.value;
    console.log(this.isCustomerID);
    payload["customerId"] = this.isCustomerID;
    payload["investmentTypesId"] = parseInt(
      this.InvestmentformData.get("investmentTypesId").value
    );
    try {
      const { data, responseCode, responseMessage } = await this.loansManager
      .createNewInvestment(payload)
      .toPromise();
      if (responseCode && responseCode.toString() === "200") {
        this.sweetAlert
          .showSuccessMessage(
            "Investment has been created successfully!",
            responseMessage
          )
          .then((data) => {
            if (this.isConfirmed) {
              window.location.reload();
            }
          });
      }
      else {
        this.sweetAlert.showErrorMessage("OOPS!", responseMessage);
       }
    } 
    catch (error) {
      this.sweetAlert.showErrorMessage(
        "OOPS!",
        "Sorry, an error occured. Try again later."
      )
    } finally {
      this.InvestmentformData.reset()
    }
  }
  //end of investment function




  //function to create a new bank account for a customer
  async AddNewAccount() {
    let payload = this.BankAccountForm.value;
    payload["customerId"] = this.isCustomerID;
    payload["bankId"] = parseInt(this.BankAccountForm.get("bankId").value);
    try {
      const { data, responseCode, responseMessage } = await this.loansManager
      .createNewAccount(payload)
      .toPromise();
      if (responseCode && responseCode.toString() === "200") {
        this.sweetAlert
          .showSuccessMessage(
            "Account has been created successfully!",
            responseMessage
          )
          .then((data) => {
            if (this.isConfirmed) {
              window.location.reload();
            }
          });
      }
      else {
        this.sweetAlert.showErrorMessage("OOPS!", responseMessage);
       }
    } 
    catch (error) {
      this.sweetAlert.showErrorMessage(
        "OOPS!",
        "Sorry, an error occured. Try again later."
      )
    } finally {
      this.BankAccountForm.reset()
    }
  }
  // end of account function
}
