import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewClientDetailsComponent } from './view-client-details.component';

describe('ViewClientDetailsComponent', () => {
  let component: ViewClientDetailsComponent;
  let fixture: ComponentFixture<ViewClientDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewClientDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewClientDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
