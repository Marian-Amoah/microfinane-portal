import { Component, OnInit } from "@angular/core";
import { BreadcrumbService } from "src/app/services/misc/breadcrumb/breadcrumb.service";
import {
  NgbModal,
  NgbModalRef,
  ModalDismissReasons,
  NgbActiveModal,
} from "@ng-bootstrap/ng-bootstrap";
import { LoansManagerService } from "src/app/services/LoansManager/loans-manager.service";
import { HttpService } from "src/app/services/http/http.service";
import { Customers, RootObject } from "src/app/interfaces/customer";
import { SweetalertService } from "src/app/services/sweetalert/sweetalert.service";
import { FormGroup, FormControl, FormBuilder } from "@angular/forms";

@Component({
  selector: "app-todo",
  templateUrl: "./todo.component.html",
  styleUrls: ["./todo.component.css"],
})
export class TodoComponent implements OnInit {

  // variable declarations
  customers: Customers[] = [];
  p: number = 1;
  closeResult: string;
  editForm!: FormGroup;
  isConfirmed: boolean = true;
  spinner: boolean = true;

  constructor(
    private crumb: BreadcrumbService,
    private loansManager: LoansManagerService,
    private sweetAlert: SweetalertService,
    private modalService: NgbModal,
    private formBuilder: FormBuilder
  ) {
    this.crumb.setCrumb([{ name: "Loan Manager", link: "/Todo" }]);
  }
  
  //modal
  open(content) {
    this.modalService.open(content, { windowClass: "dark-modal" });
  }
  //end of modal

  //creating a form group for adding customer
  formData = new FormGroup({
    firstName: new FormControl(""),
    lastName: new FormControl(""),
    dateOfBirth: new FormControl(""),
    emailAddress: new FormControl(""),
    ghanaPostGPS: new FormControl(""),
    physicalAddress: new FormControl(""),
    customerPhoto: new FormControl(""),
  });
  //end of form group for adding customer

  ngOnInit() {
    this.getAllUsers();
    //start of refresh
    this.loansManager.Refreshrequired.subscribe((response) => {
      this.getAllUsers();
    });
    //end of refresh
   

    //form group for editing customer details
    this.editForm = this.formBuilder.group({
      customerId: [""],
      firstName: [""],
      lastName: [""],
      dateOfBirth: [""],
      emailAddress: [""],
      ghanaPostGPS: [""],
      physicalAddress: [""],
      customerPhoto: [""],
    });
    //end of form group for editing customer details
  }

  //this is to get all customers data from the endpoint
  async getAllUsers() {
    const { data, responseCode, responseMessage } = await this.loansManager
      .FetchAllUsers()
      .toPromise();
    try {
      if (responseCode && responseCode.toString() === "200") {
        this.customers = data;
        console.log(this.customers)
      }
    } catch (error) {
      console.log(error);
      this.sweetAlert.showErrorMessage("OOPS!", responseMessage);
    } finally {
      this.spinner = false;
    }
  }
  //end of get all users

  //function to add a new customer
  async AddCustomer() {
    let payload = this.formData.value;
    console.log(payload);
    try {
      const { data, responseCode, responseMessage } = await this.loansManager
      .createCustomerApi(payload)
      .toPromise();
      if (responseCode && responseCode.toString() === "201") {
        this.sweetAlert
          .showSuccessMessage(
            "customer has been created successfully!",
            responseMessage
          )
      }  else {
        this.sweetAlert.showErrorMessage("OOPS!", responseMessage);
       }
    } 
    catch (error) {
      this.sweetAlert.showErrorMessage(
        "OOPS!",
        "Sorry, an error occured. Try again later."
      );
    } finally {
    this.formData.reset()
    this.spinner = false;
    }
  }
  //end of adding new client

  //function to load data onto the form
  PopulateForm(data: RootObject) {
    this.editForm.setValue(data);
  }
  // end of function to load data onto the form

  //update function
  async UpdateCustomer() {
    try {
      const { data, responseCode, responseMessage } = await this.loansManager
      .updateCustomerApi(this.editForm.value.customerId, this.editForm.value)
      .toPromise();
      if (responseCode && responseCode.toString() === "200") {
        this.customers = data;
        this.sweetAlert
          .showSuccessMessage(
            "customer has been updated successfully!",
            responseMessage
          )
          .then((data) => {
            if (this.isConfirmed) {
              this.getAllUsers();
            }
          });
      }
      else {
        this.sweetAlert.showErrorMessage("OOPS!", responseMessage);
       }
    }   catch (error) {
      this.sweetAlert.showErrorMessage(
        "OOPS!",
        "Sorry, an error occured. Try again later."
      );
    } 
  }
  //end of update function


//delete function
  deleteCustomer(customerId: number, firstName: string, lastName: string) {
    this.sweetAlert
      .showDeleteMessage(
        "<h5 style='color:#07488d'>" +
          "Are you sure you want to delete" +
          " " +
          firstName +
          " " +
          lastName +
          "</h5>"
      )
      .then((data) => {
        if (this.isConfirmed) {
          this.loansManager.deleteCustomerApi(customerId).toPromise();
        } else {
          this.sweetAlert.showErrorMessage("OOPS!", 'responseMessage');
        }
      });
  }
  //end of delete function
}
