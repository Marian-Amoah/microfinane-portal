import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { title } from 'process';
import { TodoComponent } from './todo/todo.component';
import { ViewClientDetailsComponent } from './todo/view-client-details/view-client-details.component';

const routes: Routes = [

  {
    path: '',
    redirectTo: 'Todo'
  },
  { 
    path: 'Todo',
    children: [
      { 
        path: '',
        component: TodoComponent
      },
      {
          path: 'view/:customerId',
          component: ViewClientDetailsComponent
        }
    
        ]
      }
    ]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LoansManagerRoutingModule { }
