import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LoansManagerRoutingModule } from './loans-manager-routing.module';
import { TodoComponent } from './todo/todo.component';
import { ViewClientDetailsComponent } from './todo/view-client-details/view-client-details.component';
import { PagesRoutingModule } from '../pages-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';
import { UserRedirectComponent } from '../user-redirect/user-redirect.component';
import { PagesModule } from '../pages.module';

@NgModule({
  declarations: [
    TodoComponent,
    ViewClientDetailsComponent,
  ],
  imports: [
    CommonModule,
    LoansManagerRoutingModule,
    PagesRoutingModule,
    FormsModule,
    SharedModule,
    PagesModule,
    ReactiveFormsModule
  ]
})
export class LoansManagerModule { }
