import { Component, OnInit } from '@angular/core';
import {  CustomerService } from '../services/customer.service';
import { Customers, RootObject } from '../customer';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.sass']
})
export class DashboardComponent implements OnInit {

  constructor(private customerService:CustomerService) { }

  customers:Customers[] = [];
  loans:Customers[] = [];
  investments:Customers[] = [];
  banks:Customers[] = [];

  ngOnInit(): void {
    this.customerService.customerApiGet().subscribe(
      { next:(data : RootObject) => {
        this.customers = data.data;
      },
      error: (error)=> {
        console.log(error)
      }
      })

    //this is to get all loans
    this.customerService.getLoans().subscribe(
      { next:(data : RootObject) => {
        this.loans = data.data;
      },
      error: (error)=> {
        console.log(error)
      }
      })

      //this is to get all investments
    this.customerService.getInvestments().subscribe(
      { next:(data : RootObject) => {
        this.investments = data.data;
      },
      error: (error)=> {
        console.log(error)
      }
      })


      //this is to get all banks
    this.customerService.getBanks().subscribe(
      { next:(data : RootObject) => {
        this.banks = data.data;
      },
      error: (error)=> {
        console.log(error)
      }
      })
  }

}
